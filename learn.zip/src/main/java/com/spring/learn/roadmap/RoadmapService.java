package com.spring.learn.roadmap;

public interface RoadmapService {

}
