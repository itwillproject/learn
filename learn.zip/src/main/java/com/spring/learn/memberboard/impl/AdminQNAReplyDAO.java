package com.spring.learn.memberboard.impl;

import com.spring.learn.memberboard.AdminQNAReplyVO;

public interface AdminQNAReplyDAO {

		
	AdminQNAReplyVO getReply (String qnaNo);
	
		
}

