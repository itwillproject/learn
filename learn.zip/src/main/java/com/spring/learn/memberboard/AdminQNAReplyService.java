package com.spring.learn.memberboard;

public interface AdminQNAReplyService {
	
	AdminQNAReplyVO getReply(String qnaNo); // 1개의 데이터 조회
	
}
