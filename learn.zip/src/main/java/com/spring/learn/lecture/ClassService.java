package com.spring.learn.lecture;

public interface ClassService {

}
