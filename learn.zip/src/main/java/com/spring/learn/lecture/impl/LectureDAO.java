package com.spring.learn.lecture.impl;

import org.springframework.stereotype.Repository;

@Repository
public interface LectureDAO {
	// 메소드명이 Mapper 파일의 id명으로 사용
	  
	
	  
	
}





